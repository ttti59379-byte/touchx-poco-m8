# TouchX POCO M8 (лимит 10x, пакет com.touchx.sensitivix8)

Лимит множителя на ползунках X/Y поднят с 5x до 10x
(`SeekBar.setMax(400)` -> `900` в `MainActivity.settingsDialog`, файл `app/classes3.dex`).

Сборка: Actions -> Build APK -> Run workflow -> скачать TouchX_POCO_M8.apk из Artifacts.
Репозиторий лучше сделать приватным: в нём лежит keystore для подписи.
