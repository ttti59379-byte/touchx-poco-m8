# TouchX 10x (POCO M8)

Папка `app/` - содержимое APK (манифест, ресурсы, dex). Gradle не нужен.

Изменения относительно оригинала:
- лимит ползунков X/Y: 5x -> 10x (`SeekBar.setMax(400)` -> `900` в `classes3.dex`);
- пакет: com.touchx.sensitivim8 -> com.touchx.sensitivix8 (отдельная установка);
- подпись: собственный ключ `touchx.keystore` (alias touchx, пароль touchx123).

Сборка: вкладка Actions -> Build APK -> Run workflow -> APK в разделе Artifacts.
Репозиторий держите приватным: в нём лежит ключ подписи.
