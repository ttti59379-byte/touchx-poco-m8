# TouchX 10x (POCO M8)

`app/` - содержимое APK (манифест, DEX, ресурсы). Gradle не используется.

Изменения относительно оригинала:
- лимит ползунков X/Y: 5x -> 10x (SeekBar.setMax 400 -> 900 в MainActivity.settingsDialog, classes3.dex);
- пакет: com.touchx.sensitivim8 -> com.touchx.sensitivix8;
- подпись: собственный ключ из GitHub Secrets (в репозитории ключа нет).

Секреты (Settings -> Secrets and variables -> Actions): KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.
Необязательная переменная (вкладка Variables): ORIGINAL_CERT_SHA256 - SHA-256 подписи оригинала, сборка упадёт, если подпись совпадёт.

Сборка: Actions -> Build APK -> Run workflow -> APK в Artifacts (один файл TouchX_10x.apk).
